package com.li.testpopwindow;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.AdapterView.OnItemClickListener;

public class TestPullPopWindowActivity extends Activity {
	private MenuPopWindow popMenu;
	private Context context;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); // �����ޱ���

		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_testpopwindow);
		context = TestPullPopWindowActivity.this;

		popMenu = new MenuPopWindow(context);
		DisplayMetrics dm = new DisplayMetrics();
		this.getWindowManager().getDefaultDisplay().getMetrics(dm);

		Log.e("lmf", ">>>>>>>>>>>>>>>" + dm.widthPixels + ":" + dm.heightPixels);

		Button button1 = (Button) findViewById(R.id.button1);
		button1.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.e("lmf", "onclick>>>>>>>>");
				if (popMenu.isShowing()) {
					popMenu.dismiss();
				} else {
					popMenu.show(v);
				}
			}
		});

	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		Log.e("lmf", "onBackPressed>>>>>>>>>>");
		if (popMenu.isShowing()) {
			popMenu.dismiss();
		} else {
			super.onBackPressed();
		}

	}

}