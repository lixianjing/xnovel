package com.li.testpopwindow;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.ViewFlipper;

public class MenuPopWindow implements View.OnClickListener {

	private static final int INDEX_TOOLS_PAGE = 0;
	private static final int INDEX_SETTINGS_PAGE = 1;

	private Context mContext;
	private PopupWindow btmPopWindow, topPopWindow;

	private Button btnTitleLeft, btnTitleRight;
	private ViewFlipper viewFlipper;
	private GridView toolsGv, settingsGv;
	private PositionSettingsDialog seekDialog;
	private ScreenSettingsDialog screenDialog;
	private FontSettingsDialog fontDialog;
	private BackgroundSettingsDialog bgSettingsDialog;
	private int curPage = INDEX_TOOLS_PAGE;

	private int[] toolsImgRes = new int[] { R.drawable.icon_chapter,
			R.drawable.icon_bookmark, R.drawable.icon_add_bookmark,
			R.drawable.icon_prev_chapter, R.drawable.icon_next_chapter,
			R.drawable.icon_auto_scroll, R.drawable.icon_screen,
			R.drawable.icon_seek };

	private int[] toolsStrsRes = new int[] { R.string.menu_pop_catalog,
			R.string.menu_pop_mark, R.string.menu_pop_add_mark,
			R.string.menu_pop_pre, R.string.menu_pop_next,
			R.string.menu_pop_auto_scroll, R.string.menu_pop_rotate,
			R.string.menu_pop_position };

	private int[] settingsImgRes = new int[] { R.drawable.icon_adjust_light,
			R.drawable.icon_adjust_font, R.drawable.icon_mode_drag,
			R.drawable.icon_theme, R.drawable.icon_share,
			R.drawable.icon_default, R.drawable.icon_feedback,
			R.drawable.icon_help };

	private int[] settingsStrsRes = new int[] { R.string.menu_pop_light,
			R.string.menu_pop_font, R.string.menu_pop_scroll_mode,
			R.string.menu_pop_background, R.string.menu_pop_theme,
			R.string.menu_pop_default, R.string.menu_pop_user,
			R.string.menu_pop_scroll };

	public MenuPopWindow(Context context) {

		// TODO Auto-generated constructor stub
		this.mContext = context;
		LayoutInflater inflater = ((Activity) context).getLayoutInflater();
		View bottomView = inflater.inflate(R.layout.menu_pop_btm, null);
		View topView = inflater.inflate(R.layout.menu_pop_top, null);

		btnTitleLeft = (Button) bottomView.findViewById(R.id.window_title_left);
		btnTitleRight = (Button) bottomView
				.findViewById(R.id.window_title_right);
		btnTitleLeft.setOnClickListener(this);
		btnTitleRight.setOnClickListener(this);
		viewFlipper = (ViewFlipper) bottomView
				.findViewById(R.id.menu_pop_viewFlipper);
		// ��viewFlipper����View
		toolsGv = (GridView) LayoutInflater.from(mContext).inflate(
				R.layout.menu_pop_btm_grid, null);
		settingsGv = (GridView) LayoutInflater.from(mContext).inflate(
				R.layout.menu_pop_btm_grid, null);
		viewFlipper.addView(toolsGv);
		viewFlipper.addView(settingsGv);
		toolsGv.setAdapter(new GirdViewAdapter(mContext, toolsStrsRes,
				toolsImgRes));
		settingsGv.setAdapter(new GirdViewAdapter(mContext, settingsStrsRes,
				settingsImgRes));
		toolsGv.setOnItemClickListener(new ToolsOnItemClickListener());
		settingsGv.setOnItemClickListener(new SettingsOnItemClickListener());
		btmPopWindow = new PopupWindow(bottomView, LayoutParams.MATCH_PARENT,
				LayoutParams.WRAP_CONTENT, true);
		btmPopWindow.setBackgroundDrawable(new BitmapDrawable());
		topPopWindow = new PopupWindow(topView, LayoutParams.MATCH_PARENT,
				LayoutParams.WRAP_CONTENT, true);
		topPopWindow.setBackgroundDrawable(new BitmapDrawable());
		setCurrentPage(INDEX_TOOLS_PAGE);
	}

	// ����ʽ ���� pop�˵� parent ���½�
	public void show(View parent) {
		// ������Ҫ����titlebar�ĸ߶�
		topPopWindow.showAtLocation(parent, Gravity.TOP, 0, 0);// ���붥����λ��
		topPopWindow.setAnimationStyle(R.style.anim_popwindow_top);
		topPopWindow.setOutsideTouchable(false);
		topPopWindow.update();

		btmPopWindow.showAtLocation(parent, Gravity.BOTTOM, 0, 0);// ����ײ���λ��
		btmPopWindow.setAnimationStyle(R.style.anim_popwindow_btm);
		btmPopWindow.setOutsideTouchable(false);
		btmPopWindow.update();

		btmPopWindow.setOnDismissListener(new OnDismissListener() {

			@Override
			public void onDismiss() {
				// TODO Auto-generated method stub
				topPopWindow.dismiss();
			}
		});

	}

	public void dismiss() {
		Log.e("lmf", "dismiss>>>>>>>>>>>>>");
		btmPopWindow.dismiss();

	}

	public boolean isShowing() {
		return btmPopWindow.isShowing();
	}

	private void setCurrentPage(int index) {

		if (index == INDEX_TOOLS_PAGE) {
			if (curPage != index) {
				viewFlipper.setInAnimation(mContext,
						R.anim.menu_flipper_right_in);
				viewFlipper.setOutAnimation(mContext,
						R.anim.menu_flipper_right_out);
				viewFlipper.showPrevious();// ���󻬶�
			}
			btnTitleLeft.setSelected(true);
			btnTitleRight.setSelected(false);
		} else {
			if (curPage != index) {
				viewFlipper.setInAnimation(mContext,
						R.anim.menu_flipper_left_in);
				viewFlipper.setOutAnimation(mContext,
						R.anim.menu_flipper_left_out);
				viewFlipper.showNext();// ���һ���
			}
			btnTitleLeft.setSelected(false);
			btnTitleRight.setSelected(true);
		}
		curPage = index;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.window_title_left:
			setCurrentPage(INDEX_TOOLS_PAGE);
			break;
		case R.id.window_title_right:
			setCurrentPage(INDEX_SETTINGS_PAGE);
			break;

		default:
			break;
		}
	}

	private class ToolsOnItemClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			Log.e("lmf", ">>>>>arg2>>>>>>>>>" + arg2);
			switch (arg2) {
			case 0:

				break;
			case 1:

				break;
			case 2:

				break;
			case 3:

				break;
			case 4:

				break;
			case 5:

				break;
			case 6:

				break;
			case 7:
				MenuPopWindow.this.dismiss();
				if (seekDialog == null) {
					seekDialog = new PositionSettingsDialog(mContext);
				}
				seekDialog.show();

				break;

			default:
				break;
			}
		}

	}

	private class SettingsOnItemClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			Log.e("lmf", "onItemClick>>>>>>>arg2>>>");
			// TODO Auto-generated method stub
			switch (arg2) {
			case 0:
				MenuPopWindow.this.dismiss();
				if (screenDialog == null) {
					screenDialog = new ScreenSettingsDialog(mContext);
				}
				screenDialog.show();
				break;
			case 1:
				MenuPopWindow.this.dismiss();
				if (fontDialog == null) {
					fontDialog = new FontSettingsDialog(mContext);
				}
				fontDialog.show();
				break;
			case 2:

				break;
			case 3:
				MenuPopWindow.this.dismiss();
				if (bgSettingsDialog == null) {
					bgSettingsDialog = new BackgroundSettingsDialog(mContext);
				}
				bgSettingsDialog.show();

				break;
			case 4:

				break;
			case 5:

				break;
			case 6:

				break;
			case 7:

				break;

			default:
				break;
			}
		}

	}
}
