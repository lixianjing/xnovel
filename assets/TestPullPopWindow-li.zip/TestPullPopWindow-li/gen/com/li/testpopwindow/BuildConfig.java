/** Automatically generated file. DO NOT MODIFY */
package com.li.testpopwindow;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}