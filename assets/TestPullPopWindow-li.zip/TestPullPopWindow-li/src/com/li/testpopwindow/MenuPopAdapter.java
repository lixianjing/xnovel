package com.li.testpopwindow;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MenuPopAdapter extends BaseAdapter {
	Context mContext;
	LayoutInflater inflater;
	private int textRes[];
	private int imgRes[];

	public MenuPopAdapter(Context context, int[] titleRes, int[] imgRes) {

		this.mContext = context;
		this.textRes = titleRes;
		this.imgRes = imgRes;
		inflater = LayoutInflater.from(context);
	}

	public int getCount() {

		return imgRes.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return imgRes[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	public View getView(int position, View currentView, ViewGroup arg2) {

		currentView = inflater.inflate(R.layout.menu_pop_btm_grid_item, null);

		ImageView imageView = (ImageView) currentView.findViewById(R.id.image);
		TextView textView = (TextView) currentView.findViewById(R.id.text);

		imageView.setBackgroundResource(imgRes[position]);
		textView.setText(textRes[position]);

		return currentView;
	}

}
