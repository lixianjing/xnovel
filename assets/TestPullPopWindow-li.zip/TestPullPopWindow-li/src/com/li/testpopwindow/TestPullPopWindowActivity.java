package com.li.testpopwindow;

import java.io.FileNotFoundException;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;

public class TestPullPopWindowActivity extends Activity {

	public static final int REQUEST_CODE_PHOTO_PICKED_WITH_DATA = 1001;

	public static final int MSG_CODE_THEME_PICK_PICTURE = 2001;

	private MenuPopWindow popMenu;
	private Context context;

	private int mWidth, mHeight;

	private OnThemePictureChangedListener pictureChangedListener;

	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			Log.e("lmf", "Handler>>>>>>>>" + msg.what);
			switch (msg.what) {
			case MSG_CODE_THEME_PICK_PICTURE:
				onPickFromGalleryChosen();
				break;

			default:
				break;
			}
			super.handleMessage(msg);
		}

	};

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); // �����ޱ���

		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_testpopwindow);

		popMenu = new MenuPopWindow(this);
		popMenu.setMainHandler(mHandler);
		DisplayMetrics dm = new DisplayMetrics();
		this.getWindowManager().getDefaultDisplay().getMetrics(dm);
		mWidth = dm.widthPixels;
		mHeight = dm.heightPixels;
		Button button1 = (Button) findViewById(R.id.button1);
		button1.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if (popMenu.isShowing()) {
					popMenu.dismiss();
				} else {
					popMenu.show(v);
				}
			}
		});

	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if (popMenu.isShowing()) {
			popMenu.dismiss();
		} else {
			super.onBackPressed();
		}

	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {

		switch (requestCode) {
		case REQUEST_CODE_PHOTO_PICKED_WITH_DATA: {
			// Ignore failed requests
			if (resultCode != Activity.RESULT_OK)
				return;
			// As we are coming back to this view, the editor will be
			// reloaded automatically,
			// which will cause the photo that is set here to disappear. To
			// prevent this,
			// we remember to set a flag which is interpreted after loading.
			// This photo is set here already to reduce flickering.
			Log.e("lmf", "Test>>>>>>>>>>");
			try {
				Uri uri = data.getData();
				if (uri != null) {
					Bitmap bitmap = BitmapFactory
							.decodeStream(getContentResolver().openInputStream(
									uri));
					if (bitmap != null) {
						pictureChangedListener.pictureChanged(bitmap);
					}
					Log.e("lmf", "Test>>>>>>>>>222>>" + uri);
				}
			} catch (Exception e) {
				Log.e("lmf", e.getMessage(), e);
			}

			break;
		}

		}
	}

	/**
	 * Launches Gallery to pick a photo.
	 */
	public void onPickFromGalleryChosen() {
		final Intent intent = getPhotoPickIntent();
		startActivityForResult(intent,
				TestPullPopWindowActivity.REQUEST_CODE_PHOTO_PICKED_WITH_DATA);
	}

	/**
	 * Constructs an intent for picking a photo from Gallery, cropping it and
	 * returning the bitmap.
	 */
	public Intent getPhotoPickIntent() {
		Intent intent = new Intent(Intent.ACTION_GET_CONTENT, null);
		intent.setType("image/*");
		return intent;
	}

	public void setOnThemePictureChangedListener(
			OnThemePictureChangedListener pictureChangedListener) {
		this.pictureChangedListener = pictureChangedListener;
	}

	public interface OnThemePictureChangedListener {
		void pictureChanged(Bitmap bitmap);
	}

}