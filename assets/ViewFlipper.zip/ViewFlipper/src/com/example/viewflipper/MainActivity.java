package com.example.viewflipper;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ViewFlipper;

public class MainActivity extends Activity implements OnGestureListener {

	private static final String TAG = "MainActivity";
	private ViewFlipper viewFlipper;
	private GestureDetector detector; // 手势检测

	Animation leftInAnimation;
	Animation leftOutAnimation;
	Animation rightInAnimation;
	Animation rightOutAnimation;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		viewFlipper = (ViewFlipper) findViewById(R.id.viewFlipper);
		detector = new GestureDetector(this, this);

		// 往viewFlipper添加View
		View view1 = LayoutInflater.from(this)
				.inflate(R.layout.activity1, null);
		View view2 = LayoutInflater.from(this)
				.inflate(R.layout.activity2, null);
		View view3 = LayoutInflater.from(this)
				.inflate(R.layout.activity3, null);
		viewFlipper.addView(view1);
		viewFlipper.addView(view2);
		viewFlipper.addView(view3);
		// 动画效果
		leftInAnimation = AnimationUtils.loadAnimation(this, R.anim.menu_flipper_left_in);
		leftOutAnimation = AnimationUtils.loadAnimation(this, R.anim.menu_flipper_left_out);
		rightInAnimation = AnimationUtils.loadAnimation(this, R.anim.menu_flipper_right_in);
		rightOutAnimation = AnimationUtils
				.loadAnimation(this, R.anim.menu_flipper_right_out);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		return this.detector.onTouchEvent(event);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	@Override
	public boolean onDown(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		// TODO Auto-generated method stub
		Log.i(TAG,
				"e1=" + e1.getX() + " e2=" + e2.getX() + " e1-e2="
						+ (e1.getX() - e2.getX()));
		if (e1.getX() - e2.getX() > 120) {
			viewFlipper.setInAnimation(leftInAnimation);
			viewFlipper.setOutAnimation(leftOutAnimation);
			viewFlipper.showNext();// 向右滑动
			return true;
		} else if (e1.getX() - e2.getY() < -120) {
			viewFlipper.setInAnimation(rightInAnimation);
			viewFlipper.setOutAnimation(rightOutAnimation);
			viewFlipper.showPrevious();// 向左滑动
			return true;
		}
		return false;
	}

	@Override
	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}

}
