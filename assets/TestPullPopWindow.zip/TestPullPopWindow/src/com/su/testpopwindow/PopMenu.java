package com.su.testpopwindow;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

public class PopMenu implements View.OnClickListener {

	private Context context;
	private PopupWindow popupWindow;
	private ViewPager viewPager;
	private ArrayList<View> listViews;
	private int screenwidth;

	private int currentView = 0;// ��ǰ��ͼ
	private int viewOffset;// ����ͼƬƫ����

	private Button btnTitleLeft, btnTitleRight, btnTitleMid;

	public PopMenu(Context context) {

		// TODO Auto-generated constructor stub
		this.context = context;
		LayoutInflater inflater = ((Activity) context).getLayoutInflater();
		View view = inflater.inflate(R.layout.popmenu, null);

		btnTitleLeft = (Button) view.findViewById(R.id.window_title_left);
		btnTitleRight = (Button) view.findViewById(R.id.window_title_right);
		btnTitleMid = (Button) view.findViewById(R.id.window_title_mid);
		btnTitleLeft.setOnClickListener(this);
		btnTitleRight.setOnClickListener(this);
		btnTitleMid.setOnClickListener(this);

		viewPager = (ViewPager) view.findViewById(R.id.viewPagerw);
		viewPager.setFocusableInTouchMode(true);
		viewPager.setFocusable(true);

		listViews = new ArrayList<View>();
		listViews.add(inflater.inflate(R.layout.grid_menu, null));
		listViews.add(inflater.inflate(R.layout.grid_menu, null));
		listViews.add(inflater.inflate(R.layout.grid_menu, null));
		viewPager.setAdapter(new myPagerAdapter());
		// viewPager.setOnPageChangeListener(new MyOnPageChangeListener());

		popupWindow = new PopupWindow(view, LayoutParams.MATCH_PARENT, context
				.getResources().getDimensionPixelSize(R.dimen.popmenu_h));
		popupWindow.setBackgroundDrawable(new BitmapDrawable());
	}

	public int getScreenWidth() {
		DisplayMetrics dm = new DisplayMetrics();
		((Activity) context).getWindowManager().getDefaultDisplay()
				.getMetrics(dm);
		int screenW = dm.widthPixels;
		return screenW;

	}

	// ����ʽ ���� pop�˵� parent ���½�
	public void show(View parent) {
		// popupWindow.showAsDropDown(parent, -1000, context.getResources()
		// .getDimensionPixelSize(R.dimen.popmenu_yoff));

		popupWindow.showAtLocation(parent, Gravity.BOTTOM, 0, 70);// ����ײ���λ��
		popupWindow.setAnimationStyle(R.style.popwin_anim_style);
		popupWindow.setFocusable(true);
		popupWindow.setOutsideTouchable(true);
		popupWindow.update();
	}

	public void dismiss() {
		popupWindow.dismiss();
	}

	public class myPagerAdapter extends PagerAdapter {

		@Override
		public void destroyItem(View arg0, int arg1, Object arg2) {

			((ViewPager) arg0).removeView(listViews.get(arg1));

		}

		@Override
		public int getCount() {

			return listViews.size();

		}

		public Object instantiateItem(View arg0, int arg1) {

			if (arg1 < 3) {
				((ViewPager) arg0).addView(listViews.get(arg1 % 3), 0);

			}
			// �������Ӳ˵���ʱ�� �½�һ��gridviewadapter Ȼ��new��gridview ���ӵ�����Ϳ���
			GirdViewAdapter girdViewAdapter = new GirdViewAdapter(context);
			switch (arg1) {
			case 0:// ѡ�1

				GridView gridView = (GridView) arg0
						.findViewById(R.id.myGridView);

				gridView.setAdapter(girdViewAdapter);

				gridView.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {

						switch (arg2) {

						default:

							Toast.makeText(context,
									"�����GridView+ViewPager��UC�˵���" + arg2,
									Toast.LENGTH_LONG).show();
							break;
						}

					}
				});

				break;
			case 1:// ѡ�2
				GridView gridView2 = (GridView) arg0
						.findViewById(R.id.myGridView);

				gridView2.setAdapter(girdViewAdapter);

				gridView2.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {

						switch (arg2) {

						default:

							Toast.makeText(context,
									"�����GridView+ViewPager��UC�˵���" + arg2,
									Toast.LENGTH_LONG).show();
							break;
						}

					}
				});
				break;
			case 2:// ѡ�3
				GridView gridView3 = (GridView) arg0
						.findViewById(R.id.myGridView);

				gridView3.setAdapter(girdViewAdapter);

				gridView3.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {

						switch (arg2) {

						default:

							Toast.makeText(context,
									"�����GridView+ViewPager��UC�˵���" + arg2,
									Toast.LENGTH_LONG).show();
							break;
						}

					}
				});
				break;
			}

			return listViews.get(arg1);

		}

		public boolean isViewFromObject(View arg0, Object arg1) {

			return arg0 == (arg1);

		}

	}

	// public class MyOnPageChangeListener implements OnPageChangeListener {
	//
	// // int one = viewOffset * 2 + imgWidth;// ҳ��1 -> ҳ��2 ƫ����
	// //
	// // int two = one * 2;// ҳ��1 -> ҳ��3 ƫ����
	//
	// @Override
	// public void onPageSelected(int arg0) {
	//
	// Animation animation = null;
	//
	// switch (arg0) {
	//
	// case 0:
	//
	// if (currentView == 1) {
	//
	// animation = new TranslateAnimation(one, 0, 0, 0);
	//
	// } else if (currentView == 2) {
	//
	// animation = new TranslateAnimation(two, 0, 0, 0);
	//
	// }
	//
	// break;
	//
	// case 1:
	//
	// if (currentView == 0) {
	//
	// animation = new TranslateAnimation(viewOffset, one, 0, 0);
	//
	// } else if (currentView == 2) {
	//
	// animation = new TranslateAnimation(two, one, 0, 0);
	//
	// }
	//
	// break;
	//
	// case 2:
	//
	// if (currentView == 0) {
	//
	// animation = new TranslateAnimation(viewOffset, two, 0, 0);
	//
	// } else if (currentView == 1) {
	//
	// animation = new TranslateAnimation(one, two, 0, 0);
	//
	// }
	//
	// break;
	//
	// }
	//
	// currentView = arg0;
	//
	// animation.setFillAfter(true);// True:ͼƬͣ�ڶ�������λ��
	//
	// animation.setDuration(300);
	//
	// // iv_cursor.startAnimation(animation);
	//
	// }
	//
	// @Override
	// public void onPageScrolled(int arg0, float arg1, int arg2) {
	//
	// }
	//
	// @Override
	// public void onPageScrollStateChanged(int arg0) {
	//
	// }
	//
	// }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.window_title_left:
			viewPager.setCurrentItem(0);
			btnTitleLeft.setSelected(true);
			btnTitleMid.setSelected(false);
			btnTitleRight.setSelected(false);
			break;
		case R.id.window_title_mid:
			btnTitleLeft.setSelected(false);
			btnTitleMid.setSelected(true);
			btnTitleRight.setSelected(false);
			viewPager.setCurrentItem(1);
			break;
		case R.id.window_title_right:
			btnTitleLeft.setSelected(false);
			btnTitleMid.setSelected(false);
			btnTitleRight.setSelected(true);
			viewPager.setCurrentItem(2);
			break;

		default:
			break;
		}
	}

}
