/** Automatically generated file. DO NOT MODIFY */
package com.su.testpopwindow;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}