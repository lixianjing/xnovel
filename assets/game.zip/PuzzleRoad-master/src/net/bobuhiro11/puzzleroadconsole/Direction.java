package net.bobuhiro11.puzzleroadconsole;

public enum Direction{
	up,down,left,right
};
